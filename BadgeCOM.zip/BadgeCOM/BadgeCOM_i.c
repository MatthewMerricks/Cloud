

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 7.00.0555 */
/* at Mon Sep 17 16:06:56 2012
 */
/* Compiler settings for BadgeCOM.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 7.00.0555 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, IID_IBadgeIconSyncing,0x46991EC7,0x7E83,0x4E3A,0x8E,0x21,0x75,0x77,0x92,0xBB,0xA5,0xC4);


MIDL_DEFINE_GUID(IID, IID_IBadgeIconSynced,0x0CC774F1,0x545A,0x4129,0x8B,0x09,0x86,0x55,0xC5,0x37,0x0F,0x54);


MIDL_DEFINE_GUID(IID, IID_IBadgeIconSelective,0x77D3D99A,0x1EF6,0x41F7,0xA2,0x47,0x22,0x99,0x39,0xAD,0xC1,0xD9);


MIDL_DEFINE_GUID(IID, IID_IBadgeIconFailed,0x2A204983,0x6DE7,0x42D2,0xBB,0xB1,0xFC,0xD5,0xFC,0xBD,0x80,0x26);


MIDL_DEFINE_GUID(IID, IID_IContextMenuExt,0xD2D46453,0x4FB1,0x4B94,0xA5,0x71,0xF6,0x5F,0x7B,0x5B,0xF0,0xDF);


MIDL_DEFINE_GUID(IID, LIBID_BadgeCOMLib,0xB0E0EEB6,0x3C6D,0x4F7A,0x90,0xAE,0xA0,0xC2,0x85,0xF4,0xD8,0xC1);


MIDL_DEFINE_GUID(CLSID, CLSID_BadgeIconSyncing,0x37E0ECAE,0xBEA1,0x4096,0x9D,0x84,0x44,0x0A,0x7C,0x9A,0xC9,0xE4);


MIDL_DEFINE_GUID(CLSID, CLSID_BadgeIconSynced,0x16FDC851,0xD9B0,0x4591,0xB5,0x4A,0x9A,0x50,0xD5,0x82,0x26,0xCC);


MIDL_DEFINE_GUID(CLSID, CLSID_BadgeIconSelective,0xA46EB4D6,0xB7F7,0x4255,0x91,0x2F,0xC1,0x51,0xD7,0x8E,0x26,0xF8);


MIDL_DEFINE_GUID(CLSID, CLSID_BadgeIconFailed,0x49C685C9,0xCD72,0x4588,0x88,0x00,0x2B,0x30,0xC4,0x97,0x23,0xA1);


MIDL_DEFINE_GUID(CLSID, CLSID_ContextMenuExt,0xEEA3DF1B,0xBB65,0x498A,0x9D,0xD9,0x5B,0xCD,0xA9,0xDD,0xD1,0xD7);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



