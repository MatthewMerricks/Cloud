var searchData=
[
  ['instance',['Instance',['../class_cloud_api_public_1_1_model_1_1_file_path_comparer.html#a72c16461590ae2298b139f86689991c8',1,'CloudApiPublic.Model.FilePathComparer.Instance()'],['../class_cloud_api_public_1_1_support_1_1_c_l_trace.html#a0861d3bda40d01c666acb82cef1cb595',1,'CloudApiPublic.Support.CLTrace.Instance()']]],
  ['ischild',['IsChild',['../interface_cloud_api_public_1_1_s_q_l_indexer_1_1_sql_model_1_1_i_sql_access.html#a1fd304ea212e06ebaa3a7c420e6c043d',1,'CloudApiPublic.SQLIndexer.SqlModel.ISqlAccess.IsChild()'],['../class_cloud_api_public_1_1_s_q_l_indexer_1_1_sql_model_1_1_sql_access_1_1_sql_access_base.html#adaa12256709e63d6b881804ae45c5531',1,'CloudApiPublic.SQLIndexer.SqlModel.SqlAccess.SqlAccessBase.IsChild()']]],
  ['isfolder',['IsFolder',['../struct_cloud_api_public_1_1_model_1_1_file_metadata_hashable_properties.html#accefde1677467dee8550cbf135e34462',1,'CloudApiPublic.Model.FileMetadataHashableProperties.IsFolder()'],['../class_cloud_api_public_1_1_static_1_1_trace_file_change.html#ad216ac0749ed14b9b6bbc8301509d351',1,'CloudApiPublic.Static.TraceFileChange.IsFolder()']]],
  ['issyncfrom',['IsSyncFrom',['../class_cloud_api_public_1_1_static_1_1_trace_file_change.html#a8a0e5791268bd7fc8445c8e4aeb7b9b8',1,'CloudApiPublic::Static::TraceFileChange']]]
];
