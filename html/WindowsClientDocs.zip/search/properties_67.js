var searchData=
[
  ['getlastsyncid',['getLastSyncId',['../interface_cloud_api_public_1_1_interfaces_1_1_i_sync_data_object.html#a1e0e4f15f93fce38eb008953eb1dd477',1,'CloudApiPublic::Interfaces::ISyncDataObject']]]
];
