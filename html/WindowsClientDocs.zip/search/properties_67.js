var searchData=
[
  ['getlastsyncid',['getLastSyncId',['../class_cloud_api_public_1_1_file_monitor_1_1_sync_implementation_1_1_sync_data.html#a62814239485178d07f3560cd5d6c9724',1,'CloudApiPublic::FileMonitor::SyncImplementation::SyncData']]]
];
