var searchData=
[
  ['name',['Name',['../class_cloud_api_public_1_1_model_1_1_file_path.html#a02285f24ec2d49c85778d6b5a251aa7b',1,'CloudApiPublic::Model::FilePath']]],
  ['newpath',['NewPath',['../class_cloud_api_public_1_1_model_1_1_file_change.html#ad7383c43cc51606f17c63fad6c032c7c',1,'CloudApiPublic.Model.FileChange.NewPath()'],['../class_cloud_api_public_1_1_static_1_1_trace_file_change.html#a895cff12ab5c926e56bfd4e6d9ba7241',1,'CloudApiPublic.Static.TraceFileChange.NewPath()']]]
];
