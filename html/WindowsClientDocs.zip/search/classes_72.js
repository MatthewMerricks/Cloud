var searchData=
[
  ['renamebadgepath',['RenameBadgePath',['../struct_cloud_api_public_1_1_model_1_1_rename_badge_path.html',1,'CloudApiPublic::Model']]],
  ['resources',['Resources',['../class_cloud_api_public_1_1_resources_1_1_resources.html',1,'CloudApiPublic::Resources']]],
  ['revisionchanger',['RevisionChanger',['../class_cloud_api_public_1_1_model_1_1_revision_changer.html',1,'CloudApiPublic::Model']]]
];
