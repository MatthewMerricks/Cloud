var searchData=
[
  ['oldpath',['OldPath',['../class_cloud_api_public_1_1_model_1_1_file_change.html#a08ced19e1fccebb04bf6da37f21a4216',1,'CloudApiPublic.Model.FileChange.OldPath()'],['../class_cloud_api_public_1_1_static_1_1_trace_file_change.html#a99422b2ccdfc875597b473f553a7c551',1,'CloudApiPublic.Static.TraceFileChange.OldPath()']]],
  ['osbits',['OsBits',['../class_cloud_api_public_1_1_resources_1_1_resources.html#a998c59aa83300bbd83ad7f6c6c4e9b0b',1,'CloudApiPublic::Resources::Resources']]],
  ['osversioninfoex',['OSVERSIONINFOEX',['../struct_cloud_api_public_1_1_static_1_1_native_methods_1_1_o_s_v_e_r_s_i_o_n_i_n_f_o_e_x.html',1,'CloudApiPublic::Static::NativeMethods']]]
];
