var searchData=
[
  ['updatepathargs',['UpdatePathArgs',['../class_cloud_api_public_1_1_model_1_1_update_path_args.html',1,'CloudApiPublic::Model']]],
  ['updowneventargs',['UpDownEventArgs',['../class_cloud_api_public_1_1_model_1_1_file_change_1_1_up_down_event_args.html',1,'CloudApiPublic::Model::FileChange']]],
  ['uri',['Uri',['../class_cloud_api_public_1_1_static_1_1_communication_entry.html#acfeb8baa3fbe13eb3d1d33c581900a06',1,'CloudApiPublic::Static::CommunicationEntry']]]
];
