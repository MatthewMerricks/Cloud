var searchData=
[
  ['setbadgetype',['setBadgeType',['../class_cloud_api_public_1_1_badge_n_e_t_1_1_icon_overlay.html#aef637c9c2436e382a414f57b41616a7f',1,'CloudApiPublic::BadgeNET::IconOverlay']]],
  ['setdelaybacktoinitialvalue',['SetDelayBackToInitialValue',['../class_cloud_api_public_1_1_support_1_1_delay_processable_3_01_t_01_4.html#a8ecab231a548e65ad98166d1f41219d7',1,'CloudApiPublic::Support::DelayProcessable&lt; T &gt;']]],
  ['setmd5',['SetMD5',['../class_cloud_api_public_1_1_model_1_1_file_change.html#afe3e710aa632b5c7091843dcc2fd8dcc',1,'CloudApiPublic.Model.FileChange.SetMD5(byte[] md5)'],['../class_cloud_api_public_1_1_model_1_1_file_change.html#a8843655fa58db477e9520d5f055b6406',1,'CloudApiPublic.Model.FileChange.SetMD5(string hashString)']]],
  ['shutdown',['Shutdown',['../class_cloud_api_public_1_1_badge_n_e_t_1_1_icon_overlay.html#a8f74dc2eee27f8f712f9588c7150c8fd',1,'CloudApiPublic.BadgeNET.IconOverlay.Shutdown()'],['../class_cloud_api_public_1_1_sync_1_1_sync_engine.html#abb41dd157521158572cd9ce50065fc06',1,'CloudApiPublic.Sync.SyncEngine.Shutdown()']]],
  ['start',['Start',['../class_cloud_api_public_1_1_sync_box.html#ae0ad47eda9e97480349950618ec266fa',1,'CloudApiPublic::SyncBox']]],
  ['starttimerifnotrunning',['StartTimerIfNotRunning',['../class_cloud_api_public_1_1_support_1_1_processing_queues_timer.html#ab2b799bc7901e2bfcf4cec4286b812a8',1,'CloudApiPublic::Support::ProcessingQueuesTimer']]],
  ['stop',['Stop',['../class_cloud_api_public_1_1_sync_box.html#a109192793123771a82a8c8dbbe918bb8',1,'CloudApiPublic::SyncBox']]],
  ['subscribetobadgecominitializationevents',['SubscribeToBadgeComInitializationEvents',['../class_cloud_api_public_1_1_badge_n_e_t_1_1_badge_com_pub_sub_events.html#aa33f0a14fea734e2e82098c0d8972eed',1,'CloudApiPublic::BadgeNET::BadgeComPubSubEvents']]],
  ['syncengine',['SyncEngine',['../class_cloud_api_public_1_1_sync_1_1_sync_engine.html#a3f309497452e69510b6a87ad5004d646',1,'CloudApiPublic::Sync::SyncEngine']]]
];
