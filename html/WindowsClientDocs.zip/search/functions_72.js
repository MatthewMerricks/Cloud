var searchData=
[
  ['recordcompletedsync',['RecordCompletedSync',['../class_cloud_api_public_1_1_s_q_l_indexer_1_1_indexing_agent.html#a7aa84742829670c50f733190a8e841df',1,'CloudApiPublic.SQLIndexer.IndexingAgent.RecordCompletedSync(string syncId, IEnumerable&lt; long &gt; syncedEventIds, out long syncCounter, FilePath newRootPath=null)'],['../class_cloud_api_public_1_1_s_q_l_indexer_1_1_indexing_agent.html#a00c810332347750882864aa4adf6458f',1,'CloudApiPublic.SQLIndexer.IndexingAgent.RecordCompletedSync(string syncId, IEnumerable&lt; long &gt; syncedEventIds, out long syncCounter, string newRootPath=null)']]],
  ['removedependency',['RemoveDependency',['../class_cloud_api_public_1_1_model_1_1_file_change_with_dependencies.html#ad070334b4c53167808eabbc6add69ebf',1,'CloudApiPublic::Model::FileChangeWithDependencies']]],
  ['removeeventbyid',['RemoveEventById',['../class_cloud_api_public_1_1_s_q_l_indexer_1_1_indexing_agent.html#ab7f3d7d070951526e528e998ae26c664',1,'CloudApiPublic::SQLIndexer::IndexingAgent']]],
  ['removeeventsbyids',['RemoveEventsByIds',['../class_cloud_api_public_1_1_s_q_l_indexer_1_1_indexing_agent.html#a8c26e3fad07247b53f21bb280850abd1',1,'CloudApiPublic::SQLIndexer::IndexingAgent']]],
  ['rename',['Rename',['../class_cloud_api_public_1_1_model_1_1_file_path_dictionary_3_01_t_01_4.html#a068be02b7d2cde6bae7ac43a24f362fe',1,'CloudApiPublic::Model::FilePathDictionary&lt; T &gt;']]]
];
