var searchData=
[
  ['recordcompletedsync',['RecordCompletedSync',['../interface_cloud_api_public_1_1_interfaces_1_1_i_sync_data_object.html#a77804f09d03674f67d7808a4cfd09b25',1,'CloudApiPublic.Interfaces.ISyncDataObject.RecordCompletedSync()'],['../class_cloud_api_public_1_1_sync_box.html#a5c4b8088f3cb0bf9930a547d23859386',1,'CloudApiPublic.SyncBox.RecordCompletedSync()']]],
  ['removedependency',['RemoveDependency',['../class_cloud_api_public_1_1_model_1_1_file_change_with_dependencies.html#ad070334b4c53167808eabbc6add69ebf',1,'CloudApiPublic::Model::FileChangeWithDependencies']]],
  ['rename',['Rename',['../class_cloud_api_public_1_1_model_1_1_file_path_dictionary_3_01_t_01_4.html#a068be02b7d2cde6bae7ac43a24f362fe',1,'CloudApiPublic::Model::FilePathDictionary&lt; T &gt;']]],
  ['renamebadgepath',['RenameBadgePath',['../class_cloud_api_public_1_1_badge_n_e_t_1_1_icon_overlay.html#a81102aae58189aa619fbe2fd59feb79d',1,'CloudApiPublic::BadgeNET::IconOverlay']]],
  ['run',['Run',['../class_cloud_api_public_1_1_sync_1_1_sync_engine.html#a2fd9968f27d029e66e432cc90030e817',1,'CloudApiPublic::Sync::SyncEngine']]]
];
