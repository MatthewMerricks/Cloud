var searchData=
[
  ['newevent',['newEvent',['../class_cloud_api_public_1_1_badge_n_e_t_1_1_icon_overlay_1_1badge_params_1_1new_event.html',1,'CloudApiPublic::BadgeNET::IconOverlay::badgeParams']]],
  ['notificationerroreventargs',['NotificationErrorEventArgs',['../class_cloud_api_public_1_1_push_notification_1_1_notification_error_event_args.html',1,'CloudApiPublic::PushNotification']]],
  ['notificationeventargs',['NotificationEventArgs',['../class_cloud_api_public_1_1_push_notification_1_1_notification_event_args.html',1,'CloudApiPublic::PushNotification']]],
  ['notificationresponse',['NotificationResponse',['../class_cloud_api_public_1_1_json_contracts_1_1_notification_response.html',1,'CloudApiPublic::JsonContracts']]]
];
