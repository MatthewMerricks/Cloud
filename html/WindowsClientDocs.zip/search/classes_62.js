var searchData=
[
  ['badgepathdeletedargs',['BadgePathDeletedArgs',['../class_cloud_api_public_1_1_model_1_1_badge_path_deleted_args.html',1,'CloudApiPublic::Model']]],
  ['badgepathrenamedargs',['BadgePathRenamedArgs',['../class_cloud_api_public_1_1_model_1_1_badge_path_renamed_args.html',1,'CloudApiPublic::Model']]]
];
