var searchData=
[
  ['updatepathargs',['UpdatePathArgs',['../class_cloud_api_public_1_1_model_1_1_update_path_args.html',1,'CloudApiPublic::Model']]],
  ['updowneventargs',['UpDownEventArgs',['../class_cloud_api_public_1_1_model_1_1_file_change_1_1_up_down_event_args.html',1,'CloudApiPublic::Model::FileChange']]]
];
