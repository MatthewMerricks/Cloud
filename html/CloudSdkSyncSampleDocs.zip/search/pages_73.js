var searchData=
[
  ['syncboxes_20made_20easy_21',['SyncBoxes made easy!',['../index.html',1,'']]]
];
