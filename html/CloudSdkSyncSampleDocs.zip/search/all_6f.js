var searchData=
[
  ['oldpath',['OldPath',['../class_cloud_api_public_1_1_model_1_1_file_change.html#a08ced19e1fccebb04bf6da37f21a4216',1,'CloudApiPublic.Model.FileChange.OldPath()'],['../class_cloud_api_public_1_1_static_1_1_trace_file_change.html#a99422b2ccdfc875597b473f553a7c551',1,'CloudApiPublic.Static.TraceFileChange.OldPath()']]],
  ['oncollectionchanged',['OnCollectionChanged',['../class_cloud_api_public_1_1_event_message_receiver_1_1_delay_change_observable_collection_3_01_t_01_4.html#add8dc59e3efa0ccadc1e2ec257441365',1,'CloudApiPublic::EventMessageReceiver::DelayChangeObservableCollection&lt; T &gt;']]],
  ['operator_20filepath',['operator FilePath',['../class_cloud_api_public_1_1_model_1_1_file_path.html#a207de9e47985b6aebd7ff55402cad10c',1,'CloudApiPublic.Model.FilePath.operator FilePath(DirectoryInfo directory)'],['../class_cloud_api_public_1_1_model_1_1_file_path.html#a487405c44f1fdfb000153cff0b5fb82c',1,'CloudApiPublic.Model.FilePath.operator FilePath(FileInfo file)'],['../class_cloud_api_public_1_1_model_1_1_file_path.html#a02e6124740c2197434373db93c843932',1,'CloudApiPublic.Model.FilePath.operator FilePath(string fullPath)']]],
  ['osbits',['OsBits',['../class_cloud_api_public_1_1_resources_1_1_resources.html#a998c59aa83300bbd83ad7f6c6c4e9b0b',1,'CloudApiPublic::Resources::Resources']]],
  ['osversioninfoex',['OSVERSIONINFOEX',['../struct_cloud_api_public_1_1_static_1_1_native_methods_1_1_o_s_v_e_r_s_i_o_n_i_n_f_o_e_x.html',1,'CloudApiPublic::Static::NativeMethods']]]
];
