var searchData=
[
  ['oldpath',['OldPath',['../class_cloud_api_public_1_1_model_1_1_file_change.html#a08ced19e1fccebb04bf6da37f21a4216',1,'CloudApiPublic::Model.FileChange.OldPath()'],['../class_cloud_api_public_1_1_static_1_1_trace_file_change.html#a99422b2ccdfc875597b473f553a7c551',1,'CloudApiPublic::Static.TraceFileChange.OldPath()']]],
  ['operator_20clerror',['operator CLError',['../class_cloud_api_public_1_1_model_1_1_c_l_error.html#a349aeca184c92d02d4aa81b5b9805267',1,'CloudApiPublic::Model::CLError']]],
  ['operator_20filepath',['operator FilePath',['../class_cloud_api_public_1_1_model_1_1_file_path.html#a207de9e47985b6aebd7ff55402cad10c',1,'CloudApiPublic::Model.FilePath.operator FilePath(DirectoryInfo directory)'],['../class_cloud_api_public_1_1_model_1_1_file_path.html#a487405c44f1fdfb000153cff0b5fb82c',1,'CloudApiPublic::Model.FilePath.operator FilePath(FileInfo file)'],['../class_cloud_api_public_1_1_model_1_1_file_path.html#a02e6124740c2197434373db93c843932',1,'CloudApiPublic::Model.FilePath.operator FilePath(string fullPath)']]],
  ['operator_2b',['operator+',['../class_cloud_api_public_1_1_model_1_1_c_l_error.html#a72a84def290381289e4ed48b362aefdf',1,'CloudApiPublic::Model.CLError.operator+(CLError err, Exception ex)'],['../class_cloud_api_public_1_1_model_1_1_c_l_error.html#ad6f2ec679ea426dec5a2067d06a849c9',1,'CloudApiPublic::Model.CLError.operator+(CLError err, Stream fStream)']]],
  ['osversioninfo',['OSVersionInfo',['../class_cloud_api_public_1_1_static_1_1_o_s_version_info.html',1,'CloudApiPublic::Static']]],
  ['osversioninfoex',['OSVERSIONINFOEX',['../struct_cloud_api_public_1_1_static_1_1_native_methods_1_1_o_s_v_e_r_s_i_o_n_i_n_f_o_e_x.html',1,'CloudApiPublic::Static::NativeMethods']]]
];
