var searchData=
[
  ['_5fprocessor_5finfo_5funion',['_PROCESSOR_INFO_UNION',['../struct_cloud_api_public_1_1_static_1_1_o_s_version_info_1_1___p_r_o_c_e_s_s_o_r___i_n_f_o___u_n_i_o_n.html',1,'CloudApiPublic::Static::OSVersionInfo']]]
];
