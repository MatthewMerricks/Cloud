var searchData=
[
  ['uri',['Uri',['../class_cloud_api_public_1_1_static_1_1_communication_entry.html#acfeb8baa3fbe13eb3d1d33c581900a06',1,'CloudApiPublic::Static::CommunicationEntry']]]
];
