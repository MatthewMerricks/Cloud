var searchData=
[
  ['setmd5',['SetMD5',['../class_cloud_api_public_1_1_model_1_1_file_change.html#afe3e710aa632b5c7091843dcc2fd8dcc',1,'CloudApiPublic::Model.FileChange.SetMD5(byte[] md5)'],['../class_cloud_api_public_1_1_model_1_1_file_change.html#a8843655fa58db477e9520d5f055b6406',1,'CloudApiPublic::Model.FileChange.SetMD5(string hashString)']]],
  ['shutdownschedulers',['ShutdownSchedulers',['../class_cloud_api_public_1_1_c_l_sync.html#a150338311c93398031613a014205d319',1,'CloudApiPublic::CLSync']]],
  ['start',['Start',['../class_cloud_api_public_1_1_c_l_sync.html#aa70ff641c52f3678a94bc8942559b5ac',1,'CloudApiPublic::CLSync']]],
  ['stop',['Stop',['../class_cloud_api_public_1_1_c_l_sync.html#aa76639968094d5dec2ec19e10163612f',1,'CloudApiPublic::CLSync']]],
  ['syncreset',['SyncReset',['../class_cloud_api_public_1_1_c_l_sync.html#a81d09690e5f271bf5cb75f86a855e201',1,'CloudApiPublic::CLSync']]]
];
