var searchData=
[
  ['recordcompletedsync',['RecordCompletedSync',['../class_cloud_api_public_1_1_c_l_sync.html#ae42abebf3134701ec50ea49002eb8291',1,'CloudApiPublic::CLSync']]]
];
