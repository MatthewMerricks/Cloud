var searchData=
[
  ['serverid',['ServerId',['../class_cloud_api_public_1_1_model_1_1_file_metadata.html#a99c3b71952f33ca8be0f93af17f3b98c',1,'CloudApiPublic::Model::FileMetadata']]],
  ['servicepack',['ServicePack',['../class_cloud_api_public_1_1_static_1_1_o_s_version_info.html#aa12306baec1ae537f2c0cebe383d5aea',1,'CloudApiPublic::Static::OSVersionInfo']]],
  ['size',['Size',['../struct_cloud_api_public_1_1_model_1_1_file_metadata_hashable_properties.html#ade86f4137b38370bc8a7e3e73721a2a2',1,'CloudApiPublic::Model::FileMetadataHashableProperties']]],
  ['status',['Status',['../class_cloud_api_public_1_1_r_e_s_t_1_1_c_l_http_rest_1_1_base_c_l_http_rest_result.html#ab61af6b8547ba859e2fec74725bd527b',1,'CloudApiPublic::REST::CLHttpRest::BaseCLHttpRestResult']]],
  ['storagekey',['StorageKey',['../class_cloud_api_public_1_1_model_1_1_file_metadata.html#a0290dee37319988ca953fb76c9502cd1',1,'CloudApiPublic::Model::FileMetadata']]],
  ['syncboxid',['SyncBoxId',['../interface_cloud_api_public_1_1_interfaces_1_1_i_http_settings.html#a1eafc03d5c8bda11c19562bd7a3cdcfd',1,'CloudApiPublic::Interfaces::IHttpSettings']]],
  ['syncroot',['SyncRoot',['../interface_cloud_api_public_1_1_interfaces_1_1_i_sync_settings.html#a662415673548d8374f63b50d5e58b8ba',1,'CloudApiPublic::Interfaces::ISyncSettings']]]
];
