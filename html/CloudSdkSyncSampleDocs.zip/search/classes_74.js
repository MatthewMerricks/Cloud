var searchData=
[
  ['transferprogress',['TransferProgress',['../class_cloud_api_public_1_1_r_e_s_t_1_1_transfer_progress.html',1,'CloudApiPublic::REST']]],
  ['transferupdateargs',['TransferUpdateArgs',['../class_cloud_api_public_1_1_model_1_1_transfer_update_args.html',1,'CloudApiPublic::Model']]]
];
