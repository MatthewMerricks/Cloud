var searchData=
[
  ['revision',['Revision',['../class_cloud_api_public_1_1_model_1_1_file_metadata.html#a92dcb8b7561985fc7e817f154f50b61d',1,'CloudApiPublic::Model::FileMetadata']]],
  ['revisionversion',['RevisionVersion',['../class_cloud_api_public_1_1_static_1_1_o_s_version_info.html#a8491a7b7c8f9d43a435fbed52f46bdb7',1,'CloudApiPublic::Static::OSVersionInfo']]]
];
