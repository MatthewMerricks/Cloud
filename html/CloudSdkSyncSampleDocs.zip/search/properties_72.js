var searchData=
[
  ['revision',['Revision',['../class_cloud_api_public_1_1_model_1_1_file_metadata.html#a92dcb8b7561985fc7e817f154f50b61d',1,'CloudApiPublic::Model.FileMetadata.Revision()'],['../class_cloud_api_public_1_1_static_1_1_trace_file_change.html#a029dfa11d6a6dc91af7f680418234749',1,'CloudApiPublic::Static.TraceFileChange.Revision()']]],
  ['revisionversion',['RevisionVersion',['../class_cloud_api_public_1_1_static_1_1_o_s_version_info.html#a8491a7b7c8f9d43a435fbed52f46bdb7',1,'CloudApiPublic::Static::OSVersionInfo']]]
];
