var searchData=
[
  ['javascriptstringencode',['JavaScriptStringEncode',['../class_cloud_api_public_1_1_static_1_1_helpers.html#acb8621f655c8f76597553e79b3be5b33',1,'CloudApiPublic::Static.Helpers.JavaScriptStringEncode(string value)'],['../class_cloud_api_public_1_1_static_1_1_helpers.html#a32211f9b20887e0e91a9f2cf8b5bece7',1,'CloudApiPublic::Static.Helpers.JavaScriptStringEncode(string value, bool addDoubleQuotes)']]]
];
