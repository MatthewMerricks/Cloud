var searchData=
[
  ['mergetosql',['mergeToSql',['../interface_cloud_api_public_1_1_interfaces_1_1_i_sync_data_object.html#a0a80f822f5f543cc84ff07c1c9ac2a23',1,'CloudApiPublic::Interfaces::ISyncDataObject']]]
];
