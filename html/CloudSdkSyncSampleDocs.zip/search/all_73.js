var searchData=
[
  ['syncboxes_20made_20easy_21',['SyncBoxes made easy!',['../index.html',1,'']]],
  ['serverid',['ServerId',['../class_cloud_api_public_1_1_model_1_1_file_metadata.html#a99c3b71952f33ca8be0f93af17f3b98c',1,'CloudApiPublic::Model.FileMetadata.ServerId()'],['../class_cloud_api_public_1_1_static_1_1_trace_file_change.html#a3015a96ce22a895d9cfeaedb271acc14',1,'CloudApiPublic::Static.TraceFileChange.ServerId()']]],
  ['servicepack',['ServicePack',['../class_cloud_api_public_1_1_static_1_1_o_s_version_info.html#aa12306baec1ae537f2c0cebe383d5aea',1,'CloudApiPublic::Static::OSVersionInfo']]],
  ['setcountargs',['SetCountArgs',['../class_cloud_api_public_1_1_model_1_1_set_count_args.html',1,'CloudApiPublic::Model']]],
  ['setmd5',['SetMD5',['../class_cloud_api_public_1_1_model_1_1_file_change.html#afe3e710aa632b5c7091843dcc2fd8dcc',1,'CloudApiPublic::Model.FileChange.SetMD5(byte[] md5)'],['../class_cloud_api_public_1_1_model_1_1_file_change.html#a8843655fa58db477e9520d5f055b6406',1,'CloudApiPublic::Model.FileChange.SetMD5(string hashString)']]],
  ['shutdownschedulers',['ShutdownSchedulers',['../class_cloud_api_public_1_1_c_l_sync.html#a150338311c93398031613a014205d319',1,'CloudApiPublic::CLSync']]],
  ['size',['Size',['../struct_cloud_api_public_1_1_model_1_1_file_metadata_hashable_properties.html#ade86f4137b38370bc8a7e3e73721a2a2',1,'CloudApiPublic::Model.FileMetadataHashableProperties.Size()'],['../class_cloud_api_public_1_1_static_1_1_trace_file_change.html#a23025ec16f10853e1702085504acf972',1,'CloudApiPublic::Static.TraceFileChange.Size()']]],
  ['sizespecified',['SizeSpecified',['../class_cloud_api_public_1_1_static_1_1_trace_file_change.html#a31102f6e04699bcffb448470f08c0d50',1,'CloudApiPublic::Static::TraceFileChange']]],
  ['start',['Start',['../class_cloud_api_public_1_1_c_l_sync.html#a1b700631eb605ad6e065dc4296fcb912',1,'CloudApiPublic::CLSync']]],
  ['status',['Status',['../class_cloud_api_public_1_1_r_e_s_t_1_1_c_l_http_rest_1_1_base_c_l_http_rest_result.html#ab61af6b8547ba859e2fec74725bd527b',1,'CloudApiPublic::REST::CLHttpRest::BaseCLHttpRestResult']]],
  ['statuscode',['StatusCode',['../class_cloud_api_public_1_1_static_1_1_communication_entry.html#aa7e5d3ad1a3e91f1b96a8daf22f7b9d0',1,'CloudApiPublic::Static::CommunicationEntry']]],
  ['statuscodespecified',['StatusCodeSpecified',['../class_cloud_api_public_1_1_static_1_1_communication_entry.html#a31e4dd2686e7c17008cfd875140ce6f4',1,'CloudApiPublic::Static::CommunicationEntry']]],
  ['stop',['Stop',['../class_cloud_api_public_1_1_c_l_sync.html#aa76639968094d5dec2ec19e10163612f',1,'CloudApiPublic::CLSync']]],
  ['storagekey',['StorageKey',['../class_cloud_api_public_1_1_model_1_1_file_metadata.html#a0290dee37319988ca953fb76c9502cd1',1,'CloudApiPublic::Model.FileMetadata.StorageKey()'],['../class_cloud_api_public_1_1_static_1_1_trace_file_change.html#a13935156660db1dd6d25d07a7de376af',1,'CloudApiPublic::Static.TraceFileChange.StorageKey()']]],
  ['syncboxid',['SyncBoxId',['../interface_cloud_api_public_1_1_interfaces_1_1_i_http_settings.html#a1eafc03d5c8bda11c19562bd7a3cdcfd',1,'CloudApiPublic::Interfaces.IHttpSettings.SyncBoxId()'],['../class_cloud_api_public_1_1_static_1_1_entry.html#a342b647f5b4649270d924ce80f2df57e',1,'CloudApiPublic::Static.Entry.SyncBoxId()']]],
  ['syncboxidspecified',['SyncBoxIdSpecified',['../class_cloud_api_public_1_1_static_1_1_entry.html#a6492ad1a8aa1f0dbeddb5338d77f2916',1,'CloudApiPublic::Static::Entry']]],
  ['syncboxusage',['SyncBoxUsage',['../class_cloud_api_public_1_1_json_contracts_1_1_sync_box_usage.html',1,'CloudApiPublic::JsonContracts']]],
  ['syncdirection',['SyncDirection',['../namespace_cloud_api_public_1_1_static.html#a8ba5d1f6d06fa058730616f021c8974f',1,'CloudApiPublic::Static']]],
  ['syncreset',['SyncReset',['../class_cloud_api_public_1_1_c_l_sync.html#a81d09690e5f271bf5cb75f86a855e201',1,'CloudApiPublic::CLSync']]],
  ['syncroot',['SyncRoot',['../interface_cloud_api_public_1_1_interfaces_1_1_i_sync_settings.html#a662415673548d8374f63b50d5e58b8ba',1,'CloudApiPublic::Interfaces::ISyncSettings']]],
  ['system_5finfo',['SYSTEM_INFO',['../struct_cloud_api_public_1_1_static_1_1_o_s_version_info_1_1_s_y_s_t_e_m___i_n_f_o.html',1,'CloudApiPublic::Static::OSVersionInfo']]]
];
