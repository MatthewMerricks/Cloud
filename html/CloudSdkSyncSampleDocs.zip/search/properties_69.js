var searchData=
[
  ['instance',['Instance',['../class_cloud_api_public_1_1_model_1_1_file_path_comparer.html#a72c16461590ae2298b139f86689991c8',1,'CloudApiPublic::Model.FilePathComparer.Instance()'],['../class_cloud_api_public_1_1_support_1_1_c_l_trace.html#a0861d3bda40d01c666acb82cef1cb595',1,'CloudApiPublic::Support.CLTrace.Instance()']]],
  ['iserror',['IsError',['../class_cloud_api_public_1_1_model_1_1_event_message_args.html#a9fb2d21d8d3d076b1fd8b30d23493d91',1,'CloudApiPublic::Model::EventMessageArgs']]],
  ['isfolder',['IsFolder',['../struct_cloud_api_public_1_1_model_1_1_file_metadata_hashable_properties.html#accefde1677467dee8550cbf135e34462',1,'CloudApiPublic::Model.FileMetadataHashableProperties.IsFolder()'],['../class_cloud_api_public_1_1_static_1_1_trace_file_change.html#ad216ac0749ed14b9b6bbc8301509d351',1,'CloudApiPublic::Static.TraceFileChange.IsFolder()']]],
  ['issyncfrom',['IsSyncFrom',['../class_cloud_api_public_1_1_static_1_1_trace_file_change.html#a8a0e5791268bd7fc8445c8e4aeb7b9b8',1,'CloudApiPublic::Static::TraceFileChange']]]
];
