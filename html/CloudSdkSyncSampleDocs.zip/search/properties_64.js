var searchData=
[
  ['databasefolder',['DatabaseFolder',['../interface_cloud_api_public_1_1_interfaces_1_1_i_sync_settings_advanced.html#a3e0380120ac6062772306878cb2a948c',1,'CloudApiPublic::Interfaces::ISyncSettingsAdvanced']]],
  ['dependencies',['Dependencies',['../class_cloud_api_public_1_1_static_1_1_trace_file_change.html#ae59a01ca9928f8ffe53da95ff4fa62b1',1,'CloudApiPublic::Static::TraceFileChange']]],
  ['deviceid',['DeviceId',['../interface_cloud_api_public_1_1_interfaces_1_1_i_http_settings.html#afbb2c8a398151aac2e835be10353b1f1',1,'CloudApiPublic::Interfaces::IHttpSettings']]],
  ['devicename',['DeviceName',['../interface_cloud_api_public_1_1_interfaces_1_1_i_sync_settings_advanced.html#a6c77d27d7e668673e0739f84d500e5f4',1,'CloudApiPublic::Interfaces::ISyncSettingsAdvanced']]],
  ['direction',['Direction',['../class_cloud_api_public_1_1_model_1_1_file_change.html#ae9286566d391fe9d646db55e20b1ccab',1,'CloudApiPublic::Model.FileChange.Direction()'],['../class_cloud_api_public_1_1_static_1_1_communication_entry.html#a1ce7240a45fbab0747aed47f1cdd65fe',1,'CloudApiPublic::Static.CommunicationEntry.Direction()']]]
];
