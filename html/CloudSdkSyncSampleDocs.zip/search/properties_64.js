var searchData=
[
  ['databasefolder',['DatabaseFolder',['../interface_cloud_api_public_1_1_interfaces_1_1_i_sync_settings_advanced.html#a3e0380120ac6062772306878cb2a948c',1,'CloudApiPublic::Interfaces::ISyncSettingsAdvanced']]],
  ['deviceid',['DeviceId',['../interface_cloud_api_public_1_1_interfaces_1_1_i_http_settings.html#afbb2c8a398151aac2e835be10353b1f1',1,'CloudApiPublic::Interfaces::IHttpSettings']]],
  ['devicename',['DeviceName',['../interface_cloud_api_public_1_1_interfaces_1_1_i_sync_settings_advanced.html#a6c77d27d7e668673e0739f84d500e5f4',1,'CloudApiPublic::Interfaces::ISyncSettingsAdvanced']]],
  ['direction',['Direction',['../class_cloud_api_public_1_1_model_1_1_file_change.html#ae9286566d391fe9d646db55e20b1ccab',1,'CloudApiPublic::Model::FileChange']]]
];
