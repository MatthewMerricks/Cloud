var searchData=
[
  ['osversioninfoex',['OSVERSIONINFOEX',['../struct_cloud_api_public_1_1_static_1_1_native_methods_1_1_o_s_v_e_r_s_i_o_n_i_n_f_o_e_x.html',1,'CloudApiPublic::Static::NativeMethods']]]
];
