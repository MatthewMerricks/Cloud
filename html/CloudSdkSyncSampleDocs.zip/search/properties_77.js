var searchData=
[
  ['windowsyncstatus_5ftitle',['WindowSyncStatus_Title',['../class_cloud_api_public_1_1_event_message_receiver_1_1_event_message_receiver.html#a45b7136a4f3ee4989305d2d27fd65703',1,'CloudApiPublic::EventMessageReceiver::EventMessageReceiver']]]
];
