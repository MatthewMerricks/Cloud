var searchData=
[
  ['udid',['Udid',['../interface_cloud_api_public_1_1_interfaces_1_1_i_http_settings.html#a7f318613a1276ec8f27adaa79e097f5d',1,'CloudApiPublic::Interfaces::IHttpSettings']]],
  ['uri',['Uri',['../class_cloud_api_public_1_1_static_1_1_communication_entry.html#acfeb8baa3fbe13eb3d1d33c581900a06',1,'CloudApiPublic::Static::CommunicationEntry']]]
];
