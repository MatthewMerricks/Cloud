var searchData=
[
  ['win32_5ffind_5fdata',['WIN32_FIND_DATA',['../struct_cloud_api_public_1_1_s_q_l_indexer_1_1_static_1_1_native_methods_1_1_w_i_n32___f_i_n_d___d_a_t_a.html',1,'CloudApiPublic::SQLIndexer::Static::NativeMethods']]]
];
