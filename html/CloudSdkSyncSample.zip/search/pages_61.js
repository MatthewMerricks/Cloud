var searchData=
[
  ['a_20guide_20to_20the_20cloud_20api_20design',['A Guide to the Cloud API Design',['../_dev_only_page1.html',1,'']]]
];
