﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace TestFade.Converters
{
    [ValueConversion(typeof(double), typeof(Duration))]
    public class DoubleSecondsToDuration : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null)
            {
                return null;
            }

            double castValue;
            if (value is double)
            {
                castValue = (double)value;
            }
            else
            {
                string valueString;
                if (value is string)
                {
                    valueString = (string)value;
                }
                else
                {
                    valueString = value.ToString();
                }

                if (!double.TryParse(valueString, out castValue))
                {
                    return null;
                }
            }

            if (double.IsNaN(castValue)
                || double.IsInfinity(castValue)
                || castValue < 0)
            {
                return null;
            }

            return new Duration(TimeSpan.FromSeconds(castValue));
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            Nullable<Duration> castValue = value as Nullable<Duration>;

            if (castValue == null)
            {
                return double.NaN;
            }

            return ((Duration)castValue).TimeSpan.TotalSeconds;
        }
    }
}
