﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace TestFade
{
    public sealed class BindingAndTriggerValue
    {
        public Binding Binding { get; set; }
        public object Value { get; set; }
    }
}