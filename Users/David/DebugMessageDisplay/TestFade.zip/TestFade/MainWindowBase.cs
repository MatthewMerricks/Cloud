﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace TestFade
{
    public class MainWindowBase : Window
    {
        private BindingEvaluator toOpaqueEvaluator = null;

        public static readonly DependencyProperty ToOpaqueBindingProperty = DependencyProperty.Register(
            "ToOpaqueBinding", typeof(BindingAndTriggerValue), typeof(MainWindowBase), new PropertyMetadata(null, new PropertyChangedCallback(ToOpaqueBindingChanged)));

        private static void ToOpaqueBindingChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            if (e.OldValue != null)
            {
                ((MainWindowBase)sender).RemoveToOpaqueBinding();
            }

            ((MainWindowBase)sender).ApplyToOpaqueBinding((BindingAndTriggerValue)e.NewValue);
        }

        private void RemoveToOpaqueBinding()
        {
            if (toOpaqueEvaluator != null)
            {
                toOpaqueEvaluator.RemoveBinding();
                toOpaqueEvaluator = null;
            }
        }

        private void ApplyToOpaqueBinding(BindingAndTriggerValue toAdd)
        {
            if (toAdd != null)
            {
                Type comparisonType = toAdd.Value == null ? typeof(object) : toAdd.Value.GetType();
                global::System.Linq.Expressions.ParameterExpression compareValue = global::System.Linq.Expressions.Expression.Parameter(typeof(object), "compareValue");
                global::System.Linq.Expressions.ParameterExpression bindingArg = global::System.Linq.Expressions.Expression.Parameter(typeof(object), "bindingArg");
                global::System.Linq.Expressions.UnaryExpression convertValue = global::System.Linq.Expressions.Expression.Convert(compareValue, comparisonType);
                global::System.Linq.Expressions.UnaryExpression convertBindingArg = global::System.Linq.Expressions.Expression.Convert(bindingArg, comparisonType);
                global::System.Linq.Expressions.BinaryExpression testEquality = global::System.Linq.Expressions.Expression.Equal(convertBindingArg, convertValue);
                Func<object, object, bool> runComparison = global::System.Linq.Expressions.Expression.Lambda<Func<object, object, bool>>(testEquality, compareValue, bindingArg).Compile();

                this.toOpaqueEvaluator = new BindingEvaluator(toAdd.Binding,
                    (bindingE) =>
                    {
                        if (runComparison(toAdd.Value, bindingE.NewValue))
                        {
                            this.RaiseToOpaqueChanged();
                        }
                    });
            }
        }

        public BindingAndTriggerValue ToOpaqueBinding
        {
            get
            {
                return (BindingAndTriggerValue)this.GetValue(ToOpaqueBindingProperty);
            }
            set
            {
                this.SetValue(ToOpaqueBindingProperty, value);
            }
        }

        // Create a custom routed event by first registering a RoutedEventID 
        // This event uses the bubbling routing strategy 
        public static readonly RoutedEvent ToOpaqueChangedEvent = EventManager.RegisterRoutedEvent(
            "ToOpaqueChanged", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(MainWindowBase));

        // Provide CLR accessors for the event 
        public event RoutedEventHandler ToOpaqueChanged
        {
            add { AddHandler(ToOpaqueChangedEvent, value); }
            remove { RemoveHandler(ToOpaqueChangedEvent, value); }
        }

        // This method raises the ToOpaqueChanged event 
        private void RaiseToOpaqueChanged()
        {
            RoutedEventArgs newEventArgs = new RoutedEventArgs(MainWindowBase.ToOpaqueChangedEvent);
            RaiseEvent(newEventArgs);
        }
    }
}