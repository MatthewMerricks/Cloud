﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace TestFade
{
    public class NotifyFade : INotifyPropertyChanged
    {
        public Visibility Visibility
        {
            get
            {
                return _visibility;
            }
            set
            {
                if (_visibility != value)
                {
                    _visibility = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private Visibility _visibility = Visibility.Collapsed;

        public double TimeToOpaque
        {
            get
            {
                return _timeToOpaque;
            }
            set
            {
                if (_timeToOpaque != value)
                {
                    _timeToOpaque = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private double _timeToOpaque = 0d;

        public double HalfOpaque
        {
            get
            {
                return 0.5;
            }
        }

        #region INotifyPropertyChanged member
        public event PropertyChangedEventHandler PropertyChanged;

        // This method is called by the Set accessor of each property. 
        // The CallerMemberName attribute that is applied to the optional propertyName 
        // parameter causes the property name of the caller to be substituted as an argument. 
        private void NotifyPropertyChanged([CallerMemberName] String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion
    }
}