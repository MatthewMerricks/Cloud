﻿using System;
using System.Net;
using System.Windows.Browser;
using System.ComponentModel;

namespace WebSocket4Net.JsBridge
{
    public enum ClientAccessPolicyProtocol
    {
        Http = 0,
        Tcp = 1
    }
}
