﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebSocket4Net
{
    public class WebSocketContext
    {
    }
}
