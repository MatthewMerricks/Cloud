﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WebSocket4Net for .NET 2.0")]
[assembly: AssemblyDescription("WebSocket4Net for .NET 2.0")]
[assembly: ComVisible(false)]
[assembly: Guid("68511507-A29D-4577-ADB2-F4E7C6A6BAEF")]