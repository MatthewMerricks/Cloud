﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WebSocket4Net for .NET 4.0/Mono 2.10+")]
[assembly: AssemblyDescription("WebSocket4Net for .NET 4.0/Mono 2.10+")]
[assembly: ComVisible(false)]
[assembly: Guid("4a983927-2149-4286-8f6c-6abe8be15d25")]