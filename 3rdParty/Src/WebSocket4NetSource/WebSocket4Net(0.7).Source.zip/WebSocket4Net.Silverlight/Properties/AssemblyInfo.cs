﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WebSocket4Net for Silverlight")]
[assembly: AssemblyDescription("WebSocket4Net for Silverlight")]
[assembly: ComVisible(false)]
[assembly: Guid("b59453fe-1b25-463d-a7dd-10f1cf5dbe06")]